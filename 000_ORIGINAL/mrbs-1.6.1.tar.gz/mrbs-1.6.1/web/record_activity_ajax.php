<?php
namespace MRBS;

// An Ajax function to record user activity on the client side.   (If there is some activity then
// this will be picked up and used by the appropriate session file).

require "defaultincludes.inc";
